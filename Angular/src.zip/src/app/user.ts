export class User {
    id:number | undefined;
    emailId:string | undefined;
    userName:string | undefined;
    password:string | undefined;
    constructor(){
           
        }
}
